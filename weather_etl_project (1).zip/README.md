# Weather ETL Pipeline using Airflow, Python, BigQuery

This project extracts weather data, transforms it, and loads it into BigQuery using an Airflow DAG.

# Simple Weather ETL DAG
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import requests
import pandas as pd

def extract_weather():
    pass

def transform_weather():
    pass

def load_weather():
    pass

with DAG(
    dag_id="weather_etl_pipeline",
    start_date=datetime(2025, 1, 1),
    schedule_interval="@daily",
    catchup=False,
) as dag:

    extract = PythonOperator(
        task_id="extract_weather",
        python_callable=extract_weather
    )

    transform = PythonOperator(
        task_id="transform_weather",
        python_callable=transform_weather
    )

    load = PythonOperator(
        task_id="load_weather",
        python_callable=load_weather
    )

    extract >> transform >> load
